#!/usr/bin/env bash

set -e
set -x

pytype CodeAutomation --keep-going --jobs auto
