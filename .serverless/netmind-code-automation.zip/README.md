# NetMind-CodeAutomation
The service for injecting netmind interface automatically


## Install Serverless
```
- npm config set strict-ssl false
- npm install -g serverless 
- npm install --save serverless-python-requirements
```

## Deploy
```
pip install -r requirements.txt
serverless deploy --stage dev --region us-west-2
```


